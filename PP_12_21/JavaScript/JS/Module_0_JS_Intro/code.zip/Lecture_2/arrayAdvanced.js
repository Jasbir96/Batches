// declare
// array is a collection of homogeneous data types  -> Java ,c++
// array is a collection of anything  
// let arr = [
//     1,
//     true,
//     1.1,
//     "string",
//     null,
//     [1, 2, 3, 15, 5]];
//     // get 
// console.log("null",arr[4]);
// console.log("extract 3 from 2dArray",
// arr[arr.length-1][3]);
// console.log(arr);
// function definition
// let a;
// console.log(a);
// function fn() {
//   fn1();
//   console.log("I am a function");
//   // return "Hello";
// }
// function fn1(){
//   console.log("I am fn1");
// }
// // // // //function invocation
// console.log("function", fn);
// let rVal = fn(); 
// console.log("rVal", rVal);
// let tempArr = [1, 2, 3, 15, 5];
// let temp1Arr = tempArr;
// let arr = [
//   1,
//   true,
//   1.1,
//   "string",
//   null,
//   temp1Arr,
//   fn
// ];
// console.log(" 2dArray", arr[arr.length - 2]);
// // console.log("access the last element",arr[arr.length - 1]);
// console.log("call the last element",arr[arr.length - 1]());
// // let rVal = fn();
// // console.log("rVal", rVal);
// // console.log("```````");
// console.log("rVal", fn());
// tempArr.push(20);
// console.log(temp1Arr);
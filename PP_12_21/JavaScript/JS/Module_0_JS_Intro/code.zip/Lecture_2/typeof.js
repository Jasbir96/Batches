// console.log(typeof "Hello");
// console.log(typeof true);
// // null -> object 
// console.log(typeof null);
// console.log(typeof 10);
let arr=[];
function fn() {
    console.log("fn");
}
// typeof  arr is object
console.log(typeof arr);
console.log(Array.isArray(10));
// functions
console.log(typeof fn);
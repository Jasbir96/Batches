// string -> split
input.split(" ");
// let inputArr=input.split("\n");
// let r= inputArr[0];
//  let n=inputArr[1];
//  r=Number(r);
//  n=Number(n);
   //Enter your code here
//  string that is similar to an array so use JSON.parse
// let arr= JSON.parse(input);
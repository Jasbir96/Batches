// empty array
// let arr = [];
// console.log(arr);
// loops
// array does not have fixed size;
let arr = [1, 3, 4, 5, 6];
// console.log(arr.length);
// for(let i = 0; i < arr.length; i++) {
// typecasting
// // console.log(i +" : "+ arr[i]); 
// no typecasting
// console.log(i ," : ", arr[i]);
// }
// push pop  -> add/remove Last
// console.log(arr);
// arr.pop();
// console.log(arr);
// arr.push(18)
// console.log(arr);
// unshift shift -> add/remove First
// console.log(arr);
// arr.shift();
// console.log(arr);
// arr.unshift(18);
// console.log(arr);
// slice  -> gives a copy of a subarray
// starting Idx, endingIdx-1
// let slicedArr = arr.slice(1,4);
// let slicedArr = arr.slice(1);
// console.log("slicedArr", slicedArr);
// console.log("arr",arr);
// splice  -> deletes any number 
// of elements from an index
// // console.log("arr",arr);
// let removedElems=arr.splice(2,3);
// console.log("removedElems",removedElems);
// console.log("arr",arr);
// indexOf -> idx for an element in an array
//  else -1 
// let idx = arr.indexOf(5);
// console.log("idx",idx);
// includes-> it check if 
let isPresent = arr.includes(5);
// an element is inside an array
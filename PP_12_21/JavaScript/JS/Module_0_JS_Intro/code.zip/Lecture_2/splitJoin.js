// let name = "Jasbir";
// let str = `  Hello My name is ${name} `;
// // delimiter 
// console.log(str);
// str = str.trim();
// // string => array of string
// let arrStr = str.split(" ");
// console.log(arrStr);
// // arrayString-> string 
// let string = arrStr.join("$");
// console.log(string);
// to check the type 
// input -> string


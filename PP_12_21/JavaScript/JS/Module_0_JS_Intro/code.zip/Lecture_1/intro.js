// no main  
// left to right and top to bottom 
console.log("Hello PP12 ");
console.log("Hello PP12 ");
// variable declare 
let a;
// // default value undefined
// // number -> Math no integer/float
// a = 10;
console.log(5/2);
// // string -> sir string hoti hai yha par 
// a = "i am a string";
// a = 'i am also a string';
// // boolean -> true/false
// a = true;
// // null
// a = null;
// // console.log(a);
// // summary -> variables-> declare default -> undefined
// // primitve types Js : undefined,number , string ,  boolean ,null
// //loops classes conditional are similar to java
// for (let i = 1; i <= 10; i++) {
//     if (i % 4 == 0) {
//         break;
//     }
//     console.log("Number is " + i);
// }
// // single line print 
process.stdout.write("Hello ");
process.stdout.write("Hello");
// console.log("\t hello")
let a = 10;
function fn() {
    console.log("Hello from fn");
}
let b=20;
module.exports = {
    varname: a,
    fxn: fn
}
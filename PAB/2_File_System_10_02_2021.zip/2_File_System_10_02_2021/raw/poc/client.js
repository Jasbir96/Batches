let libFile=require("./provider.js");
console.log(libFile.varname);
libFile.fxn();
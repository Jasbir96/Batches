Question:
1- If we return resolved promise from an async function why do we get pending promise?

2- which has more priority set interval or set timeout?

3-priority between set immediate promises set interval set timeout next.tick?
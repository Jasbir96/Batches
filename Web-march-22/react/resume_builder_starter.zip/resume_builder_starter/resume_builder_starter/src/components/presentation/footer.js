import React from "react";
import { NavLink } from "react-router-dom";
const footer = () => {
  return (  
  
  <footer className="footer">  
    <div></div>
  </footer>

  );
};
export default footer;

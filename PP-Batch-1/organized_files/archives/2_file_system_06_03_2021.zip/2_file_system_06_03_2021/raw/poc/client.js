// use 
// /nodejs
let libfileObj = require("./lib.js");
console.log("Inside client");
console.log(libfileObj.val)
libfileObj.func();
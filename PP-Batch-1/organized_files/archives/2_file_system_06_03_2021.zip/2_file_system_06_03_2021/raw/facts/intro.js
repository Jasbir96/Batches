// top -> bottom ,left -> right
console.log("Hello PP :)");
// variable declare 
let a;
// undefined
// basic data types -> undefined,number,string boolean ,null
// statically typed language-> java
// int a;
// dynamically typed lang
a = 10;
a = 10.1;
a = "Hi i am string";
a = 'Hi i am also a string';
a = true;
console.log("a is ", a);
a = null;
// Javascript -> syntax (Java)(Brenden eich)(Netscape)[10]
// for,while ,if else break ,return ,class ;
// search -> undefined,null
let flag = true;
let num = 24;
for (let i = 2; i * i <= num; i++) {
    if (num % i == 0) {
        flag = false;
        break;
    }
}
if(flag){
    console.log(num,"is prime");
}else{
    console.log(num,"is not prime");
}
// console.log(1/"hello");


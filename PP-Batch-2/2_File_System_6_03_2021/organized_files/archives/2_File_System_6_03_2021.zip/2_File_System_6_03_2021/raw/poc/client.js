let libfileObj = require("./lib.js");
console.log(libfileObj.a);
console.log(libfileObj.varName);
libfileObj.fn(10);